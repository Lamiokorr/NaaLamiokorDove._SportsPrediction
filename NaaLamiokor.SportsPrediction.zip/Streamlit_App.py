import streamlit as st
import pandas as pd
import joblib

#Load the trained model
model = joblib.load('Player Ratings.pkl')
scaler = joblib.load('scaler.pkl')

def predict_player_rating(movement_reactions, potential, passing, wage_eur, mentality_composure, value_eur, dribbling):
    user_input = pd.DataFrame({
        'movement_reactions': [movement_reactions],
        'potential': [potential],
        'passing': [passing],  
        'wage_eur': [wage_eur],
        'mentality_composure': [mentality_composure],
        'value_eur': [value_eur],
        'dribbling': [dribbling]
    })
       
       
    user_input_scaled = scaler.transform(user_input)
    return user_input_scaled


#Streamlit app layout
st.title('⚽ Player Rating Prediction')
st.write(
        """
        Welcome to the FIFA Player Overall Rating Prediction App!
        Enter player's values to predict their overall rating
        """)

#Collecting user input
movement_reactions = st.number_input('Movement Reactions', min_value=0, max_value=100, value=50)
potential = st.number_input('Potential', min_value=0, max_value=100, value=50)
passing = st.number_input('Passing', min_value=0, max_value=100, value=50)
wage_eur = st.number_input('Wage (EUR)', min_value=0, value=10000)
mentality_composure = st.number_input('Mentality Composure', min_value=0, max_value=100, value=50)
value_eur = st.number_input('Value (EUR)', min_value=0, value=100000)
dribbling = st.number_input('Dribbling', min_value=0, max_value=100, value=50)



 # Making predictions from user's inputs
if st.button('Predict'):
    user_input_scaled = predict_player_rating(movement_reactions, potential, passing, wage_eur, mentality_composure, value_eur, dribbling)
    prediction = model.predict(user_input_scaled)
        
    # Displaying the prediction result
    st.subheader('Prediction')
    st.write(f'The predicted overall rating is: {prediction[0]}')



